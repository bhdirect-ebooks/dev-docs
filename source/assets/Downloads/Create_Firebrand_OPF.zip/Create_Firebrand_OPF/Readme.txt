In addition to the Create Firebrand OPF script, the folder (Firebrand_Digital_Product_Lookup) along with the two files inside (Firebrand_ePub_DC_Metadata_OPF.xsl and Input.xml) should be dropped in your User Home directory for the script to work properly.

The content.opf.replacement file will be created on your desktop.