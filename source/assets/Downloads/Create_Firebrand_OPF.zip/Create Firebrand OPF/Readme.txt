In addition to the Create Firebrand OPF script, the folder (Firebrand_Digital_Product_Lookup) along with the two files inside (Firebrand_ePub_DC_Metadata_OPF.xsl and Input.xml) should be dropped in your User Home directory for the script to work properly.

The Content.opf file will be created inside the Firebrand_Digital_Product_Lookup folder.